document.getElementById('changePasswordForm').addEventListener('submit', function (e) {
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  if (newPassword !== confirmPassword) {
    e.preventDefault();
    alert("New Password and Confirm Password do not match.");
  }

  if (newPassword.length < 8) {
    e.preventDefault();
    alert("Password should be at least 8 characters long.");
  }
});
