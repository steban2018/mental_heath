document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', () => {
        input.style.borderColor = '#007BFF';
    });
    input.addEventListener('blur', () => {
        input.style.borderColor = '#ccc';
    });
});

const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirm-password');
const emailInput = document.getElementById('email');

const passwordError = document.getElementById('password-error');
const passwordStrength = document.getElementById('password-strength');
const emailError = document.getElementById('email-error');
const strengthIndicator = document.getElementById('strength-indicator');

const form = document.getElementById('registerForm');

// Validate password strength
function isStrongPassword(password) {
  return /^(?=.*[A-Z])(?=.*\d).{8,}$/.test(password);
}

// Email format validation
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Calculate password strength
function getPasswordStrength(password) {
  let strength = 0;
  if (password.length >= 8) strength += 1;
  if (/[A-Z]/.test(password)) strength += 1;
  if (/\d/.test(password)) strength += 1;
  if (/[^A-Za-z0-9]/.test(password)) strength += 1; // Special characters

  return strength;
}

// Update the strength meter
function updateStrengthMeter(password) {
  const strength = getPasswordStrength(password);
  const strengthPercent = (strength / 4) * 100;
  const color = strengthPercent === 100 ? 'green' :
               strengthPercent >= 75 ? 'yellowgreen' :
               strengthPercent >= 50 ? 'yellow' :
               'red';

  strengthIndicator.style.width = strengthPercent + '%';
  strengthIndicator.style.backgroundColor = color;

  passwordStrength.style.display = strengthPercent === 0 ? 'block' : 'none';
}

// Check if password and confirm password match
function checkPasswordMatch() {
  if (confirmPasswordInput.value === '') {
    passwordError.style.display = 'none';
    return;
  }
  if (passwordInput.value !== confirmPasswordInput.value) {
    passwordError.style.display = 'block';
  } else {
    passwordError.style.display = 'none';
  }
}

// Check the password strength on input
function checkPasswordStrength() {
  if (passwordInput.value === '') {
    strengthIndicator.style.width = '0%';
    strengthIndicator.style.backgroundColor = 'red';
    passwordStrength.style.display = 'none';
    return;
  }
  updateStrengthMeter(passwordInput.value);
}

// Check email format on input
function checkEmailFormat() {
  if (emailInput.value === '') {
    emailError.style.display = 'none';
    return;
  }
  if (!isValidEmail(emailInput.value)) {
    emailError.style.display = 'block';
  } else {
    emailError.style.display = 'none';
  }
}

// Toggle password visibility
document.getElementById('toggle-password').addEventListener('click', function () {
  const type = passwordInput.type === 'password' ? 'text' : 'password';
  passwordInput.type = type;
  this.textContent = type === 'password' ? '👁️' : '🙈';
});

document.getElementById('toggle-confirm-password').addEventListener('click', function () {
  const type = confirmPasswordInput.type === 'password' ? 'text' : 'password';
  confirmPasswordInput.type = type;
  this.textContent = type === 'password' ? '👁️' : '🙈';
});

// Real-time validation event listeners
passwordInput.addEventListener('input', () => {
  checkPasswordStrength();
  checkPasswordMatch();
});

confirmPasswordInput.addEventListener('input', checkPasswordMatch);
emailInput.addEventListener('input', checkEmailFormat);

// Form submit validation
form.addEventListener('submit', function (e) {
  const isValid =
    isStrongPassword(passwordInput.value) &&
    passwordInput.value === confirmPasswordInput.value &&
    isValidEmail(emailInput.value);

  if (!isValid) {
    e.preventDefault();
    checkPasswordStrength();
    checkPasswordMatch();
    checkEmailFormat();
  }
});

console.log("Script loaded!");