const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const session = require('express-session');
const app = express();
const PORT = process.env.PORT || 3000;

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'your_mysql_user', // change this
  password: 'your_mysql_password', // change this
  database: 'mental_health_db'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

// Middleware and setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: 'quiz_secret', resave: false, saveUninitialized: true }));

// ==========================
// Admin Dashboard
// ==========================
app.get('/dashboard', (req, res) => {
  res.render('dashboard'); // views/dashboard.ejs
});

// ==========================
// Admin - View Questions
// ==========================
app.get('/admin', (req, res) => {
  const getQuestions = `SELECT * FROM questions ORDER BY id ASC`;
  db.query(getQuestions, (err, results) => {
    if (err) return res.send('Database error.');
    res.render('admin', { questions: results }); // views/admin.ejs
  });
});

// ==========================
// Admin - Add Question Form
// ==========================
app.get('/admin/add-form', (req, res) => {
  res.render('add-question'); // views/add-question.ejs
});

// ==========================
// Admin - Save New Question
// ==========================
app.post('/admin/add', (req, res) => {
  const { identifier, question, type, options } = req.body;
  const insertQuestion = `INSERT INTO questions (identifier, question, type) VALUES (?, ?, ?)`;

  db.query(insertQuestion, [identifier, question, type], (err, result) => {
    if (err) return res.send('Failed to insert question.');

    const questionId = result.insertId;
    const optionList = options.split('\n').filter(Boolean);
    const insertOptions = `INSERT INTO options (question_id, option_text) VALUES ?`;
    const values = optionList.map(opt => [questionId, opt]);

    db.query(insertOptions, [values], (err) => {
      if (err) return res.send('Failed to insert options.');
      res.redirect('/admin');
    });
  });
});

// ==========================
// Quiz Routes
// ==========================

// Home redirects to quiz start
// Home redirects to admin dashboard
app.get('/', (req, res) => {
  res.redirect('/dashboard');
});

// Display quiz question
app.get('/quiz/:identifier', (req, res) => {
  const { identifier } = req.params;
  const getQuestion = `SELECT * FROM questions WHERE identifier = ?`;
  const getOptions = `SELECT option_text FROM options WHERE question_id = ?`;

  db.query(getQuestion, [identifier], (err, questionResults) => {
    if (err || questionResults.length === 0) return res.redirect('/result');
    const question = questionResults[0];
    db.query(getOptions, [question.id], (err, optionResults) => {
      if (err) return res.redirect('/result');
      const options = optionResults.map(opt => opt.option_text);
      res.render('quiz', { question, options });
    });
  });
});

// Handle quiz answer
app.post('/quiz/:identifier', (req, res) => {
  const { identifier } = req.params;
  const sessionId = req.sessionID;
  const answer = req.body[identifier];
  const saveAnswer = `INSERT INTO answers (session_id, question_identifier, answer) VALUES (?, ?, ?)`;

  db.query(saveAnswer, [sessionId, identifier, answer], err => {
    if (err) console.error(err);

    const nextQuery = `
      SELECT identifier FROM questions 
      WHERE id > (SELECT id FROM questions WHERE identifier = ?) 
      ORDER BY id ASC LIMIT 1
    `;
    db.query(nextQuery, [identifier], (err, result) => {
      if (result && result.length > 0) {
        res.redirect(`/quiz/${result[0].identifier}`);
      } else {
        res.redirect('/result');
      }
    });
  });
});

// ==========================
// Show Result Page
// ==========================
app.get('/result', (req, res) => {
  const sessionId = req.sessionID;

  const getAnswers = `
    SELECT q.question, a.answer 
    FROM answers a
    JOIN questions q ON a.question_identifier = q.identifier
    WHERE a.session_id = ?
  `;

  db.query(getAnswers, [sessionId], (err, results) => {
    if (err) {
      console.error('Error fetching answers:', err);
      return res.send('Database error while retrieving results.');
    }

    res.render('result', { answers: results });
  });
});

// ==========================
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
