
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');
const bcrypt = require('bcrypt');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 15 * 60 * 1000 } // 15 minutes
}));

// Middleware to protect routes
function requireLogin(req, res, next) {
  if (req.session && req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('login', { error: null });
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const query = 'SELECT * FROM users WHERE username = ?';

  db.query(query, [username], (err, results) => {
    if (err || results.length === 0) {
      return res.render('login', { error: 'Invalid credentials.' });
    }

    const user = results[0];
    bcrypt.compare(password, user.password, (err, match) => {
      if (err || !match) {
        return res.render('login', { error: 'Invalid credentials.' });
      }

      req.session.user = {
        id: user.id,
        username: user.username
      };

      res.redirect('/booking');
    });
  });
});

app.get('/register', (req, res) => {
  res.render('register', { error: null });
});

app.post('/register', (req, res) => {
  const {
    username, email, password, dob,
    country, state, telephone,
    lastname, othername, address
  } = req.body;

  const saltRounds = 10;

  bcrypt.hash(password, saltRounds, (err, hash) => {
    if (err) {
      return res.render('register', { error: 'Error hashing password.' });
    }

    const query = `
      INSERT INTO users (username, email, password, dob, country, state, telephone, lastname, othername, address)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [username, email, hash, dob, country, state, telephone, lastname, othername, address], (err) => {
      if (err) {
        //console.error(err);
        return res.render('register', { error: 'Registration failed. Username may already exist.' });
      }

      res.redirect('/login');
    });
  });
});
app.get('/booking', requireLogin, (req, res) => {
  const getProfessionals = 'SELECT id, name FROM professionals';
  const getIssueTypes = 'SELECT id, name FROM issue';

  db.query(getProfessionals, (err, professionals) => {
    if (err) {
      console.error('Error fetching professionals:', err);
      return res.send('Could not load professionals.');
    }

    db.query(getIssueTypes, (err, issueTypes) => {
      if (err) {
        console.error('Error fetching issue types:', err);
        return res.send('Could not load issue types.');
      }

      res.render('booking', {
        username: req.session.user.username,
        professionals: professionals,
        issueTypes: issueTypes
      });
    });
  });
});




app.post('/booking', requireLogin, (req, res) => {
  const { issueType, professional, dateTime } = req.body;
  const userId = req.session.user.id;

  const query = `
    INSERT INTO bookings (user_id, issue_type, professional_id, session_datetime)
    VALUES (?, ?, ?, ?)
  `;

  db.query(query, [userId, issueType, professional, dateTime], (err) => {
    if (err) {
      console.error('Booking error:', err);
      return res.status(500).send('Could not book session.');
    }

    res.redirect('/appointments');
  });
});

app.get('/appointments', requireLogin, (req, res) => {
  const userId = req.session.user.id;

  const query = `
    SELECT b.*, p.name AS professional_name
    FROM bookings b
    JOIN professionals p ON b.professional_id = p.id
    WHERE b.user_id = ?
    ORDER BY b.session_datetime ASC
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching appointments:', err);
      return res.status(500).send("Internal Server Error");
    }

    const formattedAppointments = results.map(appt => ({
      ...appt,
      formattedDate: new Date(appt.session_datetime).toLocaleDateString(),
      formattedTime: new Date(appt.session_datetime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }));

    res.render('appointments', {
      upcomingAppointments: formattedAppointments,
      username: req.session.user.username
    });
  });
});

app.get('/upcoming-session', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const now = new Date();

  const query = `
    SELECT 
      b.id AS booking_id,
      b.issue_type,
      b.session_datetime,
      b.status,
      p.name AS professional_name
    FROM bookings b
    JOIN professionals p ON b.professional_id = p.id
    WHERE b.user_id = ? 
      AND b.session_datetime > ? 
      AND b.status IN ('pending', 'confirmed')
    ORDER BY b.session_datetime ASC
    LIMIT 1
  `;

  db.query(query, [userId, now], (err, results) => {
    if (err) {
      console.error('Error retrieving upcoming session:', err);
      return res.status(500).json({ error: 'Could not fetch upcoming session' });
    }

    res.json(results[0] || { message: 'No upcoming session found' });
  });
});
///end


app.get('/profile', requireLogin, (req, res) => {
  const userId = req.session.user.id;

  const query = 'SELECT username, email, dob, country, state, telephone, lastname, othername, address FROM users WHERE id = ?';

  db.query(query, [userId], (err, results) => {
    if (err || results.length === 0) {
      console.error('Profile error:', err);
      return res.status(500).send('Could not load profile.');
    }

    res.render('profile', {
      user: results[0],
      username: req.session.user.username
    });
  });
});

app.get('/change-password', requireLogin, (req, res) => {
  res.render('change-password', {
    error: null,
    success: null,
    username: req.session.user.username
  });
});

app.post('/change-password', requireLogin, (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  const userId = req.session.user.id;
  const username = req.session.user.username;

  if (newPassword !== confirmPassword) {
    return res.render('change-password', {
      error: 'New passwords do not match.',
      success: null,
      username
    });
  }

  const query = 'SELECT password FROM users WHERE id = ?';

  db.query(query, [userId], (err, results) => {
    if (err || results.length === 0) {
      return res.render('change-password', {
        error: 'User not found.',
        success: null,
        username
      });
    }

    bcrypt.compare(currentPassword, results[0].password, (err, match) => {
      if (!match) {
        return res.render('change-password', {
          error: 'Current password is incorrect.',
          success: null,
          username
        });
      }

      bcrypt.hash(newPassword, 10, (err, hashed) => {
        if (err) {
          return res.render('change-password', {
            error: 'Error saving new password.',
            success: null,
            username
          });
        }

        const updateQuery = 'UPDATE users SET password = ? WHERE id = ?';
        db.query(updateQuery, [hashed, userId], (err) => {
          if (err) {
            return res.render('change-password', {
              error: 'Failed to update password.',
              success: null,
              username
            });
          }

          res.render('change-password', {
            error: null,
            success: 'Password updated successfully!',
            username
          });
        });
      });
    });
  });
});



// Session checker
app.get('/session-check', (req, res) => {
  res.json({ loggedIn: !!req.session.user });
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

app.get('/appointment_details', requireLogin, (req, res) => {
  res.render('appointment_details', { username: req.session.user.username });
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
